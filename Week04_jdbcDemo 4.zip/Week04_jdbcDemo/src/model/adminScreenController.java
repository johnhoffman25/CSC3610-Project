package model;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class adminScreenController implements Initializable {

	private Patient selectedPatient;

	@FXML
	private TableView<Appointment> apptTable;

	@FXML
	private TableColumn<Appointment, String> col_dos;

	@FXML
	private TableColumn<Appointment, String> col_reason;

	@FXML
	private TableColumn<Appointment, String> col_diagnosis;

	@FXML
	private TableColumn<Appointment, String> col_charge;

	@FXML
	private Label cityLabel;

	@FXML
	private Label streetAddressLabel;

	@FXML
	private Label stateLabel;

	@FXML
	private Label zipLabel;

	@FXML
	private Button logoutBtn;

	@FXML
	private Button editPtInfoBtn;

	@FXML
	private Button editChargesBtn;

	@FXML
	private Label fnameLabel;

	@FXML
	private Label lnameLabel;

	@FXML
	private Label dobLabel;

	@FXML
	private Label genderLabel;

	@FXML
	private Label phoneLabel;

	@FXML
	private Label emailLabel;

	@FXML
	private Label insuranceLabel;

	@FXML
	private Button deleteDateBtn;

	String UserID;

	ObservableList<Appointment> oblist = FXCollections.observableArrayList();

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		try {
			Connection con = DBConnector.getConnection();

			ResultSet rs = con.createStatement().executeQuery(
					"SELECT * FROM APPOINTMENTS;");

			while (rs.next()) {
				oblist.add(new Appointment(rs.getString("APP_DATE"), rs.getString("APP_REASON"),
						rs.getString("APP_DIAGNOSIS"), rs.getString("APP_CHARGE"), rs.getString("PATIENT_ID")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		col_dos.setCellValueFactory(new PropertyValueFactory<>("APP_DATE"));
		col_reason.setCellValueFactory(new PropertyValueFactory<>("APP_REASON"));
		col_diagnosis.setCellValueFactory(new PropertyValueFactory<>("APP_DIAGNOSIS"));
		col_charge.setCellValueFactory(new PropertyValueFactory<>("APP_CHARGE"));

		apptTable.setItems(oblist);

	}

	@FXML
	void changeToLogin(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader();
		String fxmlDocPath = "loginScreen.fxml";
		FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);

		AnchorPane loginParent = (AnchorPane) loader.load(fxmlStream);

		Scene loginScene = new Scene(loginParent);

		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene(loginScene);
		window.show();
	}

	@FXML
	void addDateOfService(ActionEvent event) {

	}

	@FXML
	void deleteDateofService(ActionEvent event) {

		Appointment selectedAppointment = apptTable.getSelectionModel().getSelectedItem();

		try (Connection connection = DBConnector.getConnection()) {
			PreparedStatement preparedStatement = connection.prepareStatement(
					"DELETE FROM APPOINTMENTS WHERE PATIENT_ID = '" + selectedAppointment.getPATIENT_ID()
							+ "' AND APP_DATE = '" + selectedAppointment.getAPP_DATE() + "';");
			preparedStatement.execute();
			System.out.print("\nConnected to database!\nRecord was deleted successfully\n");
		} catch (SQLException e) {
			System.out.print(e.getMessage());
		}

	}

	@FXML
	void editCharges(ActionEvent event) {

		ArrayList<Payment> paymentList = ConnectDisplayUsers.generatePaymentList();
		ArrayList<Patient> patientList = ConnectDisplayUsers.generatePatientList();

		Appointment selectedAppointment = apptTable.getSelectionModel().getSelectedItem();

		outerloop: for (Patient patient : patientList) {
			for (Payment payment : paymentList) {
				if (patient.getPATIENT_ID().equals(payment.getPATIENT_ID())) {
					selectedAppointment.setAPP_CHARGE("0.00");
					try (Connection connection = DBConnector.getConnection()) {
						PreparedStatement preparedStatement = connection.prepareStatement("UPDATE APPOINTMENTS SET "
								+ "APP_CHARGE = '0.00' WHERE PATIENT_ID = " + patient.getPATIENT_ID()
								+ " AND APP_DATE = '" + selectedAppointment.getAPP_DATE() + "';");
						preparedStatement.execute();
						System.out.print("\nConnected to database!\nPatient was updated successfully\n");
						break outerloop;
					} catch (SQLException e) {
						System.out.print(e.getMessage());
					}
				}
			}
		}

	}

	@FXML
	void editPtInfo(ActionEvent event) throws IOException {
		System.out.println("Back to Patient Screen!");
		FXMLLoader loader = new FXMLLoader();
		String fxmlDocPath = "editPtInfoScreen2.fxml";
		FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);

		AnchorPane loginParent = (AnchorPane) loader.load(fxmlStream);

		Scene loginScene = new Scene(loginParent);

		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene(loginScene);
		window.show();
	}

	public void initData(Patient patient) {
		selectedPatient = patient;
		fnameLabel.setText(selectedPatient.getFNAME());
		lnameLabel.setText(selectedPatient.getLNAME());
		dobLabel.setText(selectedPatient.getDOB());
		genderLabel.setText(selectedPatient.getGENDER());
		phoneLabel.setText(selectedPatient.getPHONE());
		emailLabel.setText(selectedPatient.getEMAIL());
		streetAddressLabel.setText(selectedPatient.getADDRESS());
		cityLabel.setText(selectedPatient.getCITY());
		zipLabel.setText(selectedPatient.getZIPCODE());
		insuranceLabel.setText(selectedPatient.getINSURANCE());

	}

}
