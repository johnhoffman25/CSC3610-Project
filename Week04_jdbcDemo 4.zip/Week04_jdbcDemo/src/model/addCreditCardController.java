package model;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class addCreditCardController {

	@FXML
	private TextField ccNumTxtField;

	@FXML
	private TextField expTxtField;

	@FXML
	private TextField pinTxtField;

	@FXML
	private Button submitBtn;

	@FXML
	private Button backBtn;

	@FXML
	private Label resultLabel;

	@FXML
	void changeToPtScreen(ActionEvent event) throws IOException {

		FXMLLoader loader = new FXMLLoader();

		String fxmlDocPath = "patientScreen.fxml";

		FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);

		AnchorPane loginParent = (AnchorPane) loader.load(fxmlStream);

		Scene loginScene = new Scene(loginParent);

		ArrayList<Patient> patientList = ConnectDisplayUsers.generatePatientList();
		ArrayList<Payment> paymentList = ConnectDisplayUsers.generatePaymentList();
		String patientID = "";
		
		for (Payment payment : paymentList) {
			if (payment.getCC_NUMBER().equals(ccNumTxtField.getText())) {
				patientID = payment.getPATIENT_ID();
				break;
			}
		}
		
		for (Patient patient : patientList) {
			if (patient.getPATIENT_ID().equals(patientID)) {
				patientScreenController ptcon = loader.getController();
				ptcon.initData(patient);
				break;
			}
		}

		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene(loginScene);
		window.show();
	}

	@FXML
	void submitCCInfo(ActionEvent event) {

		String ccNumInput = ccNumTxtField.getText();
		String ccExpInput = expTxtField.getText();
		String pinInput = pinTxtField.getText();

		try (Connection con = DBConnector.getConnection()) {
			PreparedStatement preparedStatement = con
					.prepareStatement("INSERT INTO PAYMENTS(CC_NUMBER, CC_EXP, CC_CODE, PATIENT_ID)" + " VALUES ('"
							+ ccNumInput + "', '" + ccExpInput + "'," + " '" + pinInput + "', '" + 123 + "' )");
			preparedStatement.execute();
			System.out.print("\nConnected to database!\nNew payment was added successfully\n");
			resultLabel.setText("New Payment Added Succesfully!");
		} catch (SQLException e) {
			System.out.print(e.getMessage());
		}

	}

}
