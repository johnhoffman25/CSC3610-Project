package model;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class loginController {

	@FXML
	private TextField userTextField;

	@FXML
	private PasswordField passwordText;

	@FXML
	private Button adminLoginBtn;

	@FXML
	private Button loginBtn;

	@FXML
	private Label loginResult;
	
	private Patient p1;

	@FXML
	void changeToPtLookup(ActionEvent event) throws IOException {

		ArrayList<User> userList = ConnectDisplayUsers.generateUserList();
		ArrayList<Patient> ptList = getAllPatients();
	
		String username = userTextField.getText();
		String pass = passwordText.getText();

		for (User user : userList) {
			if (username.equals(user.getUserID()) && pass.equals(user.getPassword())) {
				FXMLLoader loader = new FXMLLoader();
				String fxmlDocPath = "patientScreen.fxml";
				FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);

				AnchorPane tableParent = (AnchorPane) loader.load(fxmlStream);

				Scene ptViewScene = new Scene(tableParent);
				
				for(Patient pt : ptList) {
					if(pt.getUSER_ID().equals(user.getUserID())) {
						p1 = new Patient(pt.getPATIENT_ID(),pt.getGENDER(),pt.getDOB(),pt.getFNAME(),pt.getLNAME(),pt.getADDRESS(),
								pt.getCITY(),pt.getSTATE(), pt.getZIPCODE(), pt.getEMAIL(), pt.getINSURANCE(), pt.getPHONE(), pt.getUSER_ID());
					}
				}
				
				patientScreenController ptcon = loader.getController();
				ptcon.initData(p1);

				Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
				window.setScene(ptViewScene);
				window.show();
			} else if (username.equals("admin") && pass.equals("password")) {
				FXMLLoader loader = new FXMLLoader();
				String fxmlDocPath = "db.fxml";
				FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);

				AnchorPane tableParent = (AnchorPane) loader.load(fxmlStream);

				Scene ptLookupScene = new Scene(tableParent);

				Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
				window.setScene(ptLookupScene);
				window.show();
			} else if (userTextField.getText().isEmpty() || passwordText.getText().isEmpty()) {
				if (userTextField.getText().isEmpty()) {
					loginResult.setText("Please enter username");
				} else {
					loginResult.setText("Please enter password");
				}
			} else {
				loginResult.setText("Wrong username or password");
			}
		}

	}

	@FXML
	void changeToAdmin(ActionEvent event) throws IOException {

		String username = userTextField.getText();
		String pass = passwordText.getText();
		System.out.println("You are " + username);

		if (username.equals("admin") && pass.equals("password")) {
			FXMLLoader loader = new FXMLLoader();
			String fxmlDocPath = "newUserScreen.fxml";
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);

			AnchorPane loginParent = (AnchorPane) loader.load(fxmlStream);

			Scene loginScene = new Scene(loginParent);

			Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
			window.setScene(loginScene);
			window.show();
		} else if (userTextField.getText().isEmpty() || passwordText.getText().isEmpty()) {
			if (userTextField.getText().isEmpty()) {
				loginResult.setText("Please enter username");
			} else {
				loginResult.setText("Please enter password");
			}
		} else {
			System.out.print("Wrong username or password");
			loginResult.setText("Wrong username or password");
		}
	}
	
	public ArrayList<Patient> getAllPatients() {
		
	    ArrayList<Patient> patients = new ArrayList<Patient>();

	    try {

	        Connection con = DBConnector.getConnection();

			ResultSet rs = con.createStatement().executeQuery("SELECT * FROM PATIENTS");
	        while (rs.next()) {
	            Patient patient = new Patient(rs.getString("PATIENT_ID"), rs.getString("GENDER"), rs.getString("DOB"), rs.getString("FNAME"), rs.getString("LNAME"),
						rs.getString("ADDRESS"), rs.getString("CITY"), rs.getString("STATE"), rs.getString("ZIPCODE"), rs.getString("EMAIL"),
						rs.getString("INSURANCE"), rs.getString("PHONE"), rs.getString("USER_ID"));
	            
	            patient.setPATIENT_ID(rs.getString("PATIENT_ID"));

	            patients.add(patient);

	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return (patients);
	}

}