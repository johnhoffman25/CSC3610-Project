package patientDB;

public class ModelTable {
	
	String id,fn,ln,dob;

	public ModelTable(String id, String fn, String ln, String dob) {
		this.id = id;
		this.fn = fn;
		this.ln = ln;
		this.dob = dob;
		
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFn() {
		return fn;
	}

	public void setFn(String fn) {
		this.fn = fn;
	}

	public String getLn() {
		return ln;
	}

	public void setLn(String ln) {
		this.ln = ln;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}
	
	
	
}
