package patientDB;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class TableController implements Initializable {

	@FXML
	private TableView<ModelTable> table;
	@FXML
	private TableColumn<ModelTable, String> col_id;
	@FXML
	private TableColumn<ModelTable, String> col_fn;
	@FXML
	private TableColumn<ModelTable, String> col_ln;
	@FXML
	private TableColumn<ModelTable, String> col_dob;
	@FXML
    private Button logoutBtn;

	ObservableList<ModelTable> oblist = FXCollections.observableArrayList();

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		final String DB_URL = "jdbc:mysql://localhost:3306/database";
		final String SELECT_QUERY = "SELECT id, first, last, dob FROM patienttable";
		
		try {
			Connection con = DBConnector.getConnection();

			ResultSet rs = con.createStatement().executeQuery("select * from patienttable");
			
			while (rs.next()) {
				oblist.add(new ModelTable(rs.getString("id"), rs.getString("first"), rs.getString("last"), rs.getString("dob")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		col_id.setCellValueFactory(new PropertyValueFactory<>("id"));
		col_fn.setCellValueFactory(new PropertyValueFactory<>("fn"));
		col_ln.setCellValueFactory(new PropertyValueFactory<>("ln"));
		col_dob.setCellValueFactory(new PropertyValueFactory<>("dob"));
		
		
		table.setItems(oblist);

	}
	
	@FXML
    void logout(ActionEvent event) throws IOException {
		System.out.println("Back to Login Screen!");
    	FXMLLoader loader = new FXMLLoader();
		String fxmlDocPath = "loginScreen.fxml";
		FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);

		AnchorPane loginParent = (AnchorPane) loader.load(fxmlStream);
    	
    	Scene loginScene = new Scene (loginParent);
    	
    	loginController loginCon = loader.getController();
    	
    	Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
    	window.setScene(loginScene);
    	window.show();
    }

}
