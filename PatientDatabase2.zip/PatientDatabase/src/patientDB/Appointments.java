package patientDB;

public class Appointments {
	
	String day;
	String time;
	String doctor;
	String nurse;
	String reason;
	String diagnosis;
	Double cost;
	String [] prescription;
	
	
}
