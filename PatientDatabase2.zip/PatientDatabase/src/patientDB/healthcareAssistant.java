package patientDB;

public class healthcareAssistant {
	
	String userID;
	
	String doctor;

	public healthcareAssistant(String userID, String pw, String firstName, String lastName, String doctor) {
		this.doctor = doctor;
	}

	public String getDoctor() {
		return doctor;
	}

	public void setDoctor(String doctor) {
		this.doctor = doctor;
	}
	
}
