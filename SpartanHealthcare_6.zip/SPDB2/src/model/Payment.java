package model;

public class Payment {
	
	String CC_NUMBER;
	String CC_EXP;
	String CC_CODE;
	String PATIENT_ID;
	
	public Payment(String cC_NUMBER, String cC_EXP, String cC_CODE, String pATIENT_ID) {
		CC_NUMBER = cC_NUMBER;
		CC_EXP = cC_EXP;
		CC_CODE = cC_CODE;
		PATIENT_ID = pATIENT_ID;
	}

	public String getCC_NUMBER() {
		return CC_NUMBER;
	}

	public void setCC_NUMBER(String cC_NUMBER) {
		CC_NUMBER = cC_NUMBER;
	}

	public String getCC_EXP() {
		return CC_EXP;
	}

	public void setCC_EXP(String cC_EXP) {
		CC_EXP = cC_EXP;
	}

	public String getCC_CODE() {
		return CC_CODE;
	}

	public void setCC_CODE(String cC_CODE) {
		CC_CODE = cC_CODE;
	}
	
	public String getPATIENT_ID() {
		return PATIENT_ID;
	}

	public void setPATIENT_ID(String pATIENT_ID) {
		PATIENT_ID = pATIENT_ID;
	}

}
