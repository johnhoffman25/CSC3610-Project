package model;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class reportScreenController {

    @FXML
    private TableView<?> diagnosisTable;

    @FXML
    private TableColumn<?, ?> col_diagnosis;

    @FXML
    private TableColumn<?, ?> col_quantity;

    @FXML
    private Button backBtn;

    @FXML
    void changeToPatientLookup(ActionEvent event) throws IOException {
    	
    	System.out.println("Back to Patient Lookup Screen!");
    	FXMLLoader loader = new FXMLLoader();
		String fxmlDocPath = "db.fxml";
		
		FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);

		AnchorPane loginParent = (AnchorPane) loader.load(fxmlStream);
    	
    	Scene loginScene = new Scene (loginParent);
    	
    	Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
    	window.setScene(loginScene);
    	window.show();
    	
    }

}
