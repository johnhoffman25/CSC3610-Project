package model;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class patientScreenController {

	private Patient selectedPatient;
	
    @FXML
    private Label cityLabel;

    @FXML
    private Label streetAddressLabel;

    @FXML
    private Label stateLabel;

    @FXML
    private Label zipLabel;

    @FXML
    private Button logoutBtn;

    @FXML
    private Button editPtInfoBtn;

    @FXML
    private Button makePmtBtn;

    @FXML
    private Label fnameLabel;

    @FXML
    private Label lnameLabel;

    @FXML
    private Label dobLabel;

    @FXML
    private Label genderLabel;

    @FXML
    private Label phoneLabel;

    @FXML
    private Label emailLabel;
    
    @FXML
    private Label insuranceLabel;

    @FXML
    private Label pmtResult;

    @FXML
    private Button addCCBtn;

    @FXML
    void addCreditCardInfo(ActionEvent event) throws IOException {
    	FXMLLoader loader = new FXMLLoader();
		String fxmlDocPath = "addCreditCardScreen.fxml";
		FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
		AnchorPane ccParent = (AnchorPane) loader.load(fxmlStream);
		Scene ccScene = new Scene(ccParent);
		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene(ccScene);
		window.show();
    }

    @FXML
    void changeToLogin(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader();
		String fxmlDocPath = "loginScreen.fxml";
		FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
		AnchorPane loginParent = (AnchorPane) loader.load(fxmlStream);
		Scene loginScene = new Scene(loginParent);
		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene(loginScene);
		window.show();

    }

    @FXML
    void editPtInfo(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader();
		String fxmlDocPath = "editPtInfoScreen.fxml";
		FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
		AnchorPane editParent = (AnchorPane) loader.load(fxmlStream);
		Scene editScene = new Scene(editParent);
		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene(editScene);
		window.show();

    }

    @FXML
    void makePayment(ActionEvent event) {

    }
    
    public void initData (Patient patient) {
    	selectedPatient = patient;
    	fnameLabel.setText(selectedPatient.getFNAME());
    	lnameLabel.setText(selectedPatient.getLNAME());
    	dobLabel.setText(selectedPatient.getDOB());
    	genderLabel.setText(selectedPatient.getGENDER());
    	phoneLabel.setText(selectedPatient.getPHONE());
    	emailLabel.setText(selectedPatient.getEMAIL());
    	streetAddressLabel.setText(selectedPatient.getADDRESS());
    	cityLabel.setText(selectedPatient.getCITY());
    	zipLabel.setText(selectedPatient.getZIPCODE());
    	insuranceLabel.setText(selectedPatient.getINSURANCE());
  
    }

}
