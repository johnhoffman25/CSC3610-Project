package model;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class adminScreenController {
	
	private Patient selectedPatient;

    @FXML
    private Label cityLabel;

    @FXML
    private Label streetAddressLabel;

    @FXML
    private Label stateLabel;

    @FXML
    private Label zipLabel;

    @FXML
    private Button logoutBtn;

    @FXML
    private Button editPtInfoBtn;

    @FXML
    private Button editChargesBtn;

    @FXML
    private Label fnameLabel;

    @FXML
    private Label lnameLabel;

    @FXML
    private Label dobLabel;

    @FXML
    private Label genderLabel;

    @FXML
    private Label phoneLabel;

    @FXML
    private Label emailLabel;

    @FXML
    private Label insuranceLabel;

    @FXML
    private Button deleteDateBtn;

    @FXML
    void changeToLogin(ActionEvent event) throws IOException {
    	System.out.println("Back to Login Screen!");
    	FXMLLoader loader = new FXMLLoader();
		String fxmlDocPath = "loginScreen.fxml";
		FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);

		AnchorPane loginParent = (AnchorPane) loader.load(fxmlStream);
    	
    	Scene loginScene = new Scene (loginParent);
    	
    	Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
    	window.setScene(loginScene);
    	window.show();
    }
    
    @FXML
    void addDateOfService(ActionEvent event) {

    }

    @FXML
    void deleteDateofService(ActionEvent event) {

    }

    @FXML
    void editCharges(ActionEvent event) {

    }

    @FXML
    void editPtInfo(ActionEvent event) throws IOException {
    	System.out.println("Back to Patient Screen!");
    	FXMLLoader loader = new FXMLLoader();
		String fxmlDocPath = "editPtInfoScreen2.fxml";
		FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);

		AnchorPane loginParent = (AnchorPane) loader.load(fxmlStream);
    	
    	Scene loginScene = new Scene (loginParent);
    	
    	Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
    	window.setScene(loginScene);
    	window.show();
    }
    
    public void initData (Patient patient) {
    	selectedPatient = patient;
    	fnameLabel.setText(selectedPatient.getFNAME());
    	lnameLabel.setText(selectedPatient.getLNAME());
    	dobLabel.setText(selectedPatient.getDOB());
    	genderLabel.setText(selectedPatient.getGENDER());
    	phoneLabel.setText(selectedPatient.getPHONE());
    	emailLabel.setText(selectedPatient.getEMAIL());
    	streetAddressLabel.setText(selectedPatient.getADDRESS());
    	cityLabel.setText(selectedPatient.getCITY());
    	zipLabel.setText(selectedPatient.getZIPCODE());
    	insuranceLabel.setText(selectedPatient.getINSURANCE());
    	
    }

}
