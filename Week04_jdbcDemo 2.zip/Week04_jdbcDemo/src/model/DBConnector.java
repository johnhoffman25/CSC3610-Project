package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class DBConnector {
	
	public static Connection getConnection() throws SQLException{
		final String DB_URL = "jdbc:mysql://45.55.136.114/3610_Group4?serverTimezone=UTC";
		
		Connection connection = DriverManager.getConnection(DB_URL, "csc3610", "csc3610");
		
		return connection;
	}
}
