package model;

public class Appointment {
	
	String APP_DATE;
	String APP_CHARGE;
	String APP_REASON;
	String APP_DIAGNOSIS;
	String PATIENT_ID;

	public Appointment(String aPP_DATE, String aPP_REASON, String aPP_DIAGNOSIS, String aPP_CHARGE, String pATIENT_ID) {
		APP_DATE = aPP_DATE;
		APP_CHARGE = aPP_CHARGE;
		APP_REASON = aPP_REASON;
		APP_DIAGNOSIS = aPP_DIAGNOSIS;
		PATIENT_ID = pATIENT_ID;
	}

	public String getAPP_DATE() {
		return APP_DATE;
	}

	public void setAPP_DATE(String aPP_DATE) {
		APP_DATE = aPP_DATE;
	}

	public String getAPP_CHARGE() {
		return APP_CHARGE;
	}

	public void setAPP_CHARGE(String aPP_CHARGE) {
		APP_CHARGE = aPP_CHARGE;
	}

	public String getAPP_REASON() {
		return APP_REASON;
	}

	public void setAPP_REASON(String aPP_REASON) {
		APP_REASON = aPP_REASON;
	}

	public String getAPP_DIAGNOSIS() {
		return APP_DIAGNOSIS;
	}

	public void setAPP_DIAGNOSIS(String aPP_DIAGNOSIS) {
		APP_DIAGNOSIS = aPP_DIAGNOSIS;
	}
	
	public String getPATIENT_ID() {
		return PATIENT_ID;
	}

	public void setPATIENT_ID(String pATIENT_ID) {
		PATIENT_ID = pATIENT_ID;
	}
	
}
