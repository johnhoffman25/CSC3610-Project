package model;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class addDateController {

    @FXML
    private TextField dateTxtfield;

    @FXML
    private TextField reasonTxtfield;

    @FXML
    private TextField diagnosisTxtfield;

    @FXML
    private TextField chargeTxtfield;

    @FXML
    private Button backButton;

    @FXML
    private Button submitBtn;

    @FXML
    private Label resultLabel;

    @FXML
    void backToPreviousScreen(ActionEvent event) throws IOException {
    	System.out.println("Back to Patient Screen!");
    	
    	FXMLLoader loader = new FXMLLoader();
    	
		String fxmlDocPath = "patientScreen.fxml";
		
		FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);

		AnchorPane loginParent = (AnchorPane) loader.load(fxmlStream);
    	
    	Scene loginScene = new Scene (loginParent);
    	
    	Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
    	window.setScene(loginScene);
    	window.show();
    }

    @FXML
    void submitDate(ActionEvent event) {
    	String dateInput = dateTxtfield.getText();
    	String reasonInput = reasonTxtfield.getText();
    	String diagnosisInput = diagnosisTxtfield.getText();
    	String chargeInput = chargeTxtfield.getText();

    	
		try (Connection con = DBConnector.getConnection()){
			PreparedStatement preparedStatement = con
					.prepareStatement("INSERT INTO APPOINTMENTS(APP_DATE, APP_CHARGE, APP_REASON, APP_DIAGNOSIS, PATIENT_ID)" + " VALUES ('"+ dateInput +"', '"+ reasonInput +"',"
							+ " '"+ diagnosisInput +"', '"+ dateInput +"', '"+ 101 +"' )");
			preparedStatement.execute();
			
			System.out.print("\nConnected to database!\nNew date was added successfully\n");
			resultLabel.setText("New Date Added Succesfully!");
		} catch (SQLException e) {
			System.out.print(e.getMessage());
		}
    }

}
