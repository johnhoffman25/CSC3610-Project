//Connecting to a database, querying the database,
package model;

import java.sql.Connection;
import java.sql.Statement;
import java.util.ArrayList;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class ConnectDisplayUsers {
	public static void main(String[] args) {
		
		ArrayList<Payment> paymentList = generatePaymentList();
		
		for (Payment payment : paymentList) {
			System.out.println("CC Number: " + payment.getCC_NUMBER());
			System.out.println("CC Exp: " + payment.getCC_EXP());
			System.out.println("CC Security Code: " + payment.getCC_CODE());
			System.out.println("Patient ID: " + payment.getPATIENT_ID());
			System.out.println();
		}
		
		ArrayList<Appointment> appointmentList = generateAppointmentList();
		
		for (Appointment appointment: appointmentList) {
			System.out.println("Appointment Date: " + appointment.getAPP_DATE());
			System.out.println("Appointment Cost: " + appointment.getAPP_CHARGE());
			System.out.println("Appointment Reason: " + appointment.getAPP_REASON());
			System.out.println("Appointment Diagnosis: " + appointment.getAPP_DIAGNOSIS());
			System.out.println("Patient ID: " + appointment.getPATIENT_ID());
			System.out.println();
		}
		
	}

	public static ArrayList<Patient> generatePatientList() {

		ArrayList<Patient> patientList = new ArrayList<Patient>();

		final String DB_URL = "jdbc:mysql://45.55.136.114/3610_Group4?serverTimezone=UTC";
		final String SELECT_QUERY = "SELECT PATIENT_ID, GENDER, DOB, FNAME, LNAME, ADDRESS, CITY, STATE, ZIPCODE, EMAIL, INSURANCE, PHONE, USER_ID FROM PATIENTS";

		// Use try-catch resources to connect to and query the database
		try {
			Connection conn = DriverManager.getConnection(DB_URL, "csc3610", "csc3610");

			Statement stmt = conn.createStatement();
			ResultSet rset = stmt.executeQuery((SELECT_QUERY));

			while (rset.next()) {
				String patientID = rset.getString("PATIENT_ID");
				String gender = rset.getString("GENDER");
				String dob = rset.getString("DOB");
				String fname = rset.getString("FNAME");
				String lname = rset.getString("LNAME");
				String address = rset.getString("ADDRESS");
				String city = rset.getString("CITY");
				String state = rset.getString("STATE");
				String zipcode = rset.getString("ZIPCODE");
				String email = rset.getString("EMAIL");
				String insurance = rset.getString("INSURANCE");
				String phone = rset.getString("PHONE");
				String userID = rset.getString("USER_ID");

				Patient newPatient = new Patient(patientID, gender, dob, fname, lname, address, city, state, zipcode,
						email, insurance, phone, userID);
				patientList.add(newPatient);
			}
		} catch (SQLException sqlException) {
			sqlException.printStackTrace();
		}
		return patientList;
	}

	public static ArrayList<User> generateUserList() {

		ArrayList<User> userList = new ArrayList<User>();

		final String DB_URL = "jdbc:mysql://45.55.136.114/3610_Group4?serverTimezone=UTC";
		final String SELECT_QUERY = "SELECT USER_ID, PASSWORD FROM USERS";

		// Use try-catch resources to connect to and query the database
		try {
			Connection conn = DriverManager.getConnection(DB_URL, "csc3610", "csc3610");

			Statement stmt = conn.createStatement();
			ResultSet rset = stmt.executeQuery((SELECT_QUERY));

			while (rset.next()) {
				String userID = rset.getString("USER_ID");
				String password = rset.getString("PASSWORD");
				User newUser = new User(userID, password);
				userList.add(newUser);
			}
		} catch (SQLException sqlException) {
			sqlException.printStackTrace();
		}

		return userList;
	}
	
	public static ArrayList<Appointment> generateAppointmentList() {

		ArrayList<Appointment> appointmentList = new ArrayList<Appointment>();

		final String DB_URL = "jdbc:mysql://45.55.136.114/3610_Group4?serverTimezone=UTC";
		final String SELECT_QUERY = "SELECT APP_DATE, APP_CHARGE, APP_REASON, APP_DIAGNOSIS, PATIENT_ID FROM APPOINTMENTS";

		// Use try-catch resources to connect to and query the database
		try {
			Connection conn = DriverManager.getConnection(DB_URL, "csc3610", "csc3610");

			Statement stmt = conn.createStatement();
			ResultSet rset = stmt.executeQuery((SELECT_QUERY));

			while (rset.next()) {
				String app_date = rset.getString("APP_DATE");
				String app_charge = rset.getString("APP_CHARGE");
				String app_reason = rset.getString("APP_REASON");
				String app_diagnosis = rset.getString("APP_DIAGNOSIS");
				String patientID = rset.getString("PATIENT_ID");
				
				Appointment newAppointment = new Appointment(app_date, app_charge, app_reason, app_diagnosis, patientID);
				appointmentList.add(newAppointment);
			}
		} catch (SQLException sqlException) {
			sqlException.printStackTrace();
		}
		return appointmentList;
	}
	
	public static ArrayList<Payment> generatePaymentList() {

		ArrayList<Payment> paymentList = new ArrayList<Payment>();

		final String DB_URL = "jdbc:mysql://45.55.136.114/3610_Group4?serverTimezone=UTC";
		final String SELECT_QUERY = "SELECT CC_NUMBER, CC_EXP, CC_CODE, PATIENT_ID FROM PAYMENTS";
		
		// Use try-catch resources to connect to and query the database
		try {
			Connection conn = DriverManager.getConnection(DB_URL, "csc3610", "csc3610");

			Statement stmt = conn.createStatement();
			ResultSet rset = stmt.executeQuery((SELECT_QUERY));

			while (rset.next()) {
				String cc_number = rset.getString("CC_NUMBER");
				String cc_exp = rset.getString("CC_EXP");
				String cc_code = rset.getString("CC_CODE");
				String patientID = rset.getString("PATIENT_ID");

				Payment newPayment = new Payment(cc_number, cc_exp, cc_code, patientID);
				paymentList.add(newPayment);
			}
		} catch (SQLException sqlException) {
			sqlException.printStackTrace();
		}
		return paymentList;
	}
}
