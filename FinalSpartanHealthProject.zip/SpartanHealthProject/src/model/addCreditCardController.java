package model;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class addCreditCardController {
	
	private Patient selectedPatient;
	
	private String patientID;

	@FXML
	private TextField ccNumTxtField;

	@FXML
	private TextField expTxtField;

	@FXML
	private TextField pinTxtField;

	@FXML
	private Button submitBtn;

	@FXML
	private Button backBtn;

	@FXML
	private Label resultLabel;

	@FXML
	void changeToPtScreen(ActionEvent event) throws IOException {

		FXMLLoader loader = new FXMLLoader();

		String fxmlDocPath = "patientScreen.fxml";

		FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);

		AnchorPane loginParent = (AnchorPane) loader.load(fxmlStream);

		Scene loginScene = new Scene(loginParent);
		
		patientScreenController ptcon = loader.getController();
		ptcon.initData(selectedPatient);

		ArrayList<Patient> patientList = ConnectDisplayUsers.generatePatientList();
		ArrayList<Payment> paymentList = ConnectDisplayUsers.generatePaymentList();
		String patientID = "";
		

		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene(loginScene);
		window.show();
	}

	@FXML
	void submitCCInfo(ActionEvent event) {

		String ccNumInput = ccNumTxtField.getText();
		String ccExpInput = expTxtField.getText();
		String pinInput = pinTxtField.getText();

		try (Connection con = DBConnector.getConnection()) {
			PreparedStatement preparedStatement = con
					.prepareStatement("INSERT INTO PAYMENTS(CC_NUMBER, CC_EXP, CC_CODE, PATIENT_ID)" + " VALUES ('"
							+ ccNumInput + "', '" + ccExpInput + "'," + " '" + pinInput + "', '" + patientID + "' )");
			preparedStatement.execute();
			System.out.print("\nConnected to database!\nNew payment was added successfully\n");
			resultLabel.setText("New Payment Added Succesfully!");
		} catch (SQLException e) {
			System.out.print(e.getMessage());
		}

	}
	
	public void initData(Patient patient) {
		selectedPatient = patient;
		
		patientID = selectedPatient.getPATIENT_ID();
		
	}

}
