package model;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class editPtInfoController {

	@FXML
	private TextField fnameTxtfield;

	@FXML
	private TextField lnameTxtfield;

	@FXML
	private TextField dobTxtfield;

	@FXML
	private TextField genderTxtfield;

	@FXML
	private TextField streetTxtfield;

	@FXML
	private TextField cityTxtfield;

	@FXML
	private TextField stateTxtfield;

	@FXML
	private TextField zipTxtfield;

	@FXML
	private TextField phoneTxtfield;

	@FXML
	private TextField emailTxtfield;

	@FXML
	private TextField insuranceTxtfield;

	@FXML
	private Button submitBtn;

	@FXML
	private Button backBtn;

	@FXML
	private Label resultLabel;

	@FXML
	void changeToPreviousScreen(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader();
		String fxmlDocPath = "patientScreen.fxml";
		FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);

		AnchorPane loginParent = (AnchorPane) loader.load(fxmlStream);

		Scene loginScene = new Scene(loginParent);
		
		ArrayList<Patient> patientList = ConnectDisplayUsers.generatePatientList();
		
		for (Patient patient : patientList) {
			if (patient.getFNAME().equals(fnameTxtfield.getText()) && patient.getLNAME().equals(lnameTxtfield.getText())) {
				adminScreenController ptcon = loader.getController();
				ptcon.initData(patient);
			}
		}

		Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
		window.setScene(loginScene);
		window.show();

	}

	@FXML
	void submitPtInfo(ActionEvent event) {

		ArrayList<Patient> patientList = ConnectDisplayUsers.generatePatientList();

		String fname = fnameTxtfield.getText();
		String lname = lnameTxtfield.getText();
		String dob = dobTxtfield.getText();
		String gender = genderTxtfield.getText();
		String street = streetTxtfield.getText();
		String city = cityTxtfield.getText();
		String state = stateTxtfield.getText();
		String zipcode = zipTxtfield.getText();
		String phone = phoneTxtfield.getText();
		String email = emailTxtfield.getText();
		String insurance = insuranceTxtfield.getText();

		for (Patient patient : patientList) {
			if (fname.equals(patient.getFNAME()) && lname.equals(patient.getLNAME())) {
				try (Connection connection = DBConnector.getConnection()) {
					PreparedStatement preparedStatement = connection
							.prepareStatement("UPDATE PATIENTS SET "
									+ "DOB = '" + dob 
									+ "', GENDER = '" + gender
									+ "', ADDRESS = '" + street
									+ "', CITY = '" + city
									+ "', STATE = '" + state
									+ "', ZIPCODE = '" + zipcode
									+ "', PHONE = '" + phone
									+ "', EMAIL = '" + email
									+ "', INSURANCE = '" + insurance
									+ "' WHERE PATIENT_ID = " + patient.getPATIENT_ID() + ";");
									
					preparedStatement.execute();
					System.out.print("\nConnected to database!\nPatient was updated successfully\n");
					resultLabel.setText("Patient Updated Succesfully!");
					break;
				} catch (SQLException e) {
					System.out.print(e.getMessage());
				}
			} else {
				resultLabel.setText("Error: Patient Not Found. Patient Record Was Not Updated.");
			}
		}
	}

}
